package org.koushik.javabrains.action;

public class TutorialAction {
public String execute() {
	System.out.print("success");
	return "success";
}
}
